package avila.schiatti.virdi.model.data;

import xyz.morphia.annotations.Embedded;

public enum Gender {
    MALE, FEMALE
}
