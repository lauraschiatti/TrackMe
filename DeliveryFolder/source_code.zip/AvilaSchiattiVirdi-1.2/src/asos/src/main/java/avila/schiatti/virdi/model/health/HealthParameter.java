package avila.schiatti.virdi.model.health;

public enum HealthParameter {
    HART_RATE, SYSTOLIC, DIASTOLIC, TEMPERATURE, BLOOD_OXYGEN
}
