package avila.schiatti.virdi.jobs;

public interface Scheduler {
    void start();
    void stop();
}
