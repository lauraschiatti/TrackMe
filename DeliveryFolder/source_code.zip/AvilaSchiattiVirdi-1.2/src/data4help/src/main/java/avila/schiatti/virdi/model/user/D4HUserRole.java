package avila.schiatti.virdi.model.user;

public enum D4HUserRole {
    THIRD_PARTY, INDIVIDUAL
}
