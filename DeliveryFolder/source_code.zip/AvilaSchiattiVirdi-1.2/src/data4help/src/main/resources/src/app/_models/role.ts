export enum Role {
    Individual = 'INDIVIDUAL',
    ThirdParty = 'THIRD_PARTY'
}
