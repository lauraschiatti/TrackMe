export class User {
    userId: string;
    role: string;
    accessToken: string;
}
