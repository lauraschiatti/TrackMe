import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'app-automated-sos',
    templateUrl: './automated-sos.component.html',
    styleUrls: ['./automated-sos.component.css']
})
export class AutomatedSOSComponent implements OnInit {

    constructor() {
    }

    ngOnInit() {
    }

}
