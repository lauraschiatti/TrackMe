export enum Status {
    Approved = 'APPROVED',
    Pending = 'PENDING',
    Rejected = 'REJECTED',
}
