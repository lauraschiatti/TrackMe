import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error-unauthorized',
  templateUrl: './error-unauthorized.component.html',
  styleUrls: ['./error-unauthorized.component.css']
})
export class ErrorUnauthorizedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
