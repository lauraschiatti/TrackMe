import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'app-data4help',
    templateUrl: './data4help.component.html',
    styleUrls: ['./data4help.component.css']
})
export class Data4helpComponent implements OnInit {

    constructor() {
    }

    ngOnInit() {
    }

}
