import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'app-track4run',
    templateUrl: './track4run.component.html',
    styleUrls: ['./track4run.component.css']
})
export class Track4runComponent implements OnInit {

    constructor() {
    }

    ngOnInit() {
    }

}
