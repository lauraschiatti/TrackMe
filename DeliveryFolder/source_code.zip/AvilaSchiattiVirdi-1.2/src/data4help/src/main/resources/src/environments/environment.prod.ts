export const environment = {
    production: true,
    // baseUrl: 'http://fakerestapi.azurewebsites.net/api'
};
